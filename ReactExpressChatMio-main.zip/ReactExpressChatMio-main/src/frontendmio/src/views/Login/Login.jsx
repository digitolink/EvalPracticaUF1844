function Login () {
    return (
        <h2>Estás en el Login</h2>
    )
}

export default Login